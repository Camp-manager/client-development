import { Routes } from '@angular/router';
import { acampamentosRoutes } from './components/acampamentos/acampamentos.routes';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'menu-principal',
    pathMatch: 'full'
  },
  {
    path: 'menu-principal',
    loadComponent: () =>
      import('./components/menu-principal/menu-principal.component')
        .then(m => m.MenuPrincipalComponent),
    title: 'Menu Principal'
  },
  ...acampamentosRoutes
];
