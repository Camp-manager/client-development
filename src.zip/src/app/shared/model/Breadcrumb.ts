import { RouterHelpers } from "./RouterHelper";

export interface BreadcrumbItem {
  nome: string;
  path: string;
}

export function getBreadcrumb(path: string, rotas: RouterHelpers, trail: BreadcrumbItem[] = []): BreadcrumbItem[] {
  for (const rota of rotas) {
    const regex = new RegExp('^' + rota.path.replace(/:\w+/g, '[^/]+') + '$');
    const currentTrail = [...trail, { nome: rota.nome, path: rota.path }];

    if (regex.test(path)) {
      return currentTrail;
    }

    if (rota.children) {
      const result = getBreadcrumb(path, rota.children, currentTrail);
      if (result.length) {
        return result;
      }
    }
  }
  return [];
}

export type BreadcrumbItems = BreadcrumbItem[];
