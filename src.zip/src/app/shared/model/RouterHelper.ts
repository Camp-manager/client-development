export class RouterHelper {
  nome: string;
  path: string;
  children?: RouterHelpers;
  constructor(nome: string, path: string, children?: RouterHelpers) {
    this.nome = nome;
    this.path = path;
    this.children = children;
  }
}

export type RouterHelpers = RouterHelper[];
