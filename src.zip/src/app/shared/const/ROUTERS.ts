import { RouterHelper, RouterHelpers } from "../model/RouterHelper";

export const ROUTERS: RouterHelpers = [
  new RouterHelper('Menu Principal', '/menu-principal'),
  new RouterHelper('Acampamentos', '/acampamentos', [
    new RouterHelper('Lista de Acampamentos', '/acampamentos/lista'),
    new RouterHelper('Cadastrar Novo Acampamento', '/acampamentos/formulario'),
    new RouterHelper('Editar Acampamento', '/acampamentos/formulario/:id')
  ]),
  new RouterHelper('Equipe de Trabalho', '/equipe-trabalho')
];
