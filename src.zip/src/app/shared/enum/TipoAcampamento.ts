export enum TipoAcampamento {
  MIRIM = 'Mirim',
  FAC = 'FAC',
  SENIOR = 'Sênior',
  CASAIS = 'Casais'
}
