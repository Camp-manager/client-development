import { Component } from '@angular/core';
import { AbstractControl, Form, FormControl, FormGroup, ReactiveFormsModule, ValidatorFn, Validators } from '@angular/forms';
import { TipoAcampamento } from '../../../../shared/enum/TipoAcampamento';
import { NgFor, NgIf } from '@angular/common';

@Component({
  selector: 'app-formulario',
  imports: [ReactiveFormsModule, NgFor],
  templateUrl: './formulario.component.html',
  styleUrl: './formulario.component.scss'
})
export class FormularioComponent {

  formularioAcampamento: FormGroup;
  formularioTema: FormGroup;


  tipos = Object.values(TipoAcampamento);


  constructor() {
    this.formularioAcampamento = new FormGroup({
      dataInicio: new FormControl('', Validators.required),
      dataFim: new FormControl('', Validators.required),
      limiteCampistas: new FormControl('', [Validators.required, Validators.min(1)]),
      limiteEquipe: new FormControl('', [Validators.required, Validators.min(1)]),
    }, {
      validators: this.validarDataFimMaior()
    });
    this.formularioTema = new FormGroup({
      descricao: new FormControl('', Validators.required),
      precoCamisa: new FormControl('', [Validators.required, Validators.min(0)]),
      precoInscricao: new FormControl('', [Validators.required, Validators.min(0)]),
      tipo: new FormControl('', Validators.required),
    });
  }

  private validarDataFimMaior(): ValidatorFn {
    return (group: AbstractControl): { [key: string]: any } | null => {
      const inicio = group.get('dataInicio')?.value;
      const fim = group.get('dataFim')?.value;

      if (inicio && fim && new Date(fim) <= new Date(inicio)) {
        return { dataInvalida: 'Data fim deve ser posterior à data início' };
      }

      return null;
    };
  }

  onSubmit() {
    if (this.formularioAcampamento.valid) {
      console.log('Form submitted:', this.formularioAcampamento.value);
    } else {
      console.log('Form is invalid');
    }
  }

}
