import { Component } from '@angular/core';

@Component({
  selector: 'app-acampamentos',
  imports: [],
  templateUrl: './acampamentos.component.html',
  styleUrl: './acampamentos.component.scss'
})
export class AcampamentosComponent {

}
