import { Routes } from "@angular/router";

export const acampamentosRoutes: Routes = [
  {
    path: 'acampamentos',
    loadComponent: () =>
      import('./acampamentos.component')
        .then(m => m.AcampamentosComponent),
    title: 'Acampamentos',
  },
  {
    path: 'acampamentos/formulario',
    loadComponent: () =>
    import('./components/formulario/formulario.component')
      .then(m => m.FormularioComponent)
  },
];
