import { Component, Input } from '@angular/core';
import { ROUTERS } from '../../shared/const/ROUTERS';
import { RouterModule } from '@angular/router';
import { NgClass } from '@angular/common';

@Component({
  selector: 'router-nav',
  imports: [RouterModule, NgClass],
  templateUrl: './router-navigation.component.html',
  styleUrl: './router-navigation.component.scss'
})
export class RouterNavigationComponent {
  @Input() rotas = ROUTERS;

}
