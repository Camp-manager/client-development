import { Component } from '@angular/core';

@Component({
  selector: 'app-menu-principal',
  imports: [],
  templateUrl: './menu-principal.component.html',
  styleUrl: './menu-principal.component.scss'
})
export class MenuPrincipalComponent {

}
