import { NgFor, NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { NavigationEnd, Router, RouterModule } from '@angular/router';
import { BreadcrumbItems, getBreadcrumb } from '../../shared/model/Breadcrumb';
import { ROUTERS } from '../../shared/const/ROUTERS';

@Component({
  selector: 'breadcrumb',
  imports: [NgFor, NgIf, RouterModule],
  templateUrl: './breadcrumb.component.html',
  styleUrl: './breadcrumb.component.scss'
})
export class BreadcrumbComponent {
  breadcrumb: BreadcrumbItems = [];

  constructor(private router: Router) {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        const currentPath = event.urlAfterRedirects.split('?')[0].split('#')[0];
        this.breadcrumb = getBreadcrumb(currentPath, ROUTERS);
      }
    });
    const initialUrl = this.router.url.split('?')[0].split('#')[0];
    this.updateBreadcrumb(initialUrl);
  }

  private updateBreadcrumb(url: string) {
    this.breadcrumb = getBreadcrumb(url, ROUTERS);
  }
}
